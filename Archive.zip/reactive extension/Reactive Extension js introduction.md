### 异步编程 & 响应式编程
#### 异步编程
对于异步编程并不陌生，DOM事件处理，ajax请求都是典型的异步编程，例如鼠标点击按钮，我们在页面中通过DOM提供的事件接口（addEventListener|attachEvent）添加事件处理函数（handler），然后我们的线程去做其他事情了，在未来的某个时间点，按钮被点击，事件处理函数被执行，在这个过程中，事件处理函数不是由它在程序中所处的位置决定何时运行的，而是在未来的某个时间点被点击事件触发执行，ajax请求也是类似，由于网络情况的不稳定，不知道某个请求的响应何时到达客户端，在jquery中我们通过给ajax请求传递一个success回调函数（类似于事件处理函数），响应成功到达（时间点）客户端（事件）的时候，success函数被执行。在业务情况不复杂的时候，我们使用事件接口处理dom事件，或者使用回调函数处理ajax异步请求，就够了，但是一旦业务变得复杂，情况也许就没有容易处理了，例如在处理复杂异步请求的探索过程中，我们探索的promise 解决方案。

想象一下有这样一个页面，页面需要首先发起一个异步请求，获取后续请求列表的url前缀，然后拼接url发起两个异步请求，分别获取列表和配置文件，只有当列表和配置文件都获取到之后，并且页面加载完毕之后，才渲染列表，代码如下：

```
function(window, $, showMovieLists, showError) {
	var error,
		configDone,
		movieLists,
		queueList,
		windowLoaded,
		outputDisplayed,
		errorHandler = function() {
			// Otherwise show the error.
			error = "There was a connectivity error";

			// We may be ready to display out
			tryToDisplayOutput();
		},
		tryToDisplayOutput = function() {
			if (outputDisplayed) {
				return;
			}
			if (windowLoaded) {
				if (configDone && movieLists !== undefined) {
					if (queueList !== undefined) {
						movieLists.push(queueList);
					}
					outputDisplayed = true;
					showMovieLists(JSON.stringify(movieLists));
				}
				else if (error) {
					outputDisplayed = true;
					showError(error);
				}
			}
		},
		windowLoadHandler = function() {
			windowLoaded = true;

			// Remember to unsubscribe from events
			window.removeEventListener("load", windowLoadHandler);

			// This may be the last task we're waiting on, so try and display output.
			tryToDisplayOutput();
		};

	// Register for the load event
	window.addEventListener("load", windowLoadHandler);

	// Request the service url prefix for the users AB test
	$.getJSON(
		"http://api-global.netflix.com/abTestInformation",
		{
			success: function(abTestInformation) {
				// Request the member's config information to determine whether their instant
				// queue should be displayed.
				$.getJSON(
					"http://api-global.netflix.com/" + abTestInformation.urlPrefix + "/config",
					{
						success: function(config) {
							// Parallel retrieval of movie list could've failed,
							// in which case we don't want to issue this call.
							if (!error) {
								// If we're supposed to
								if (config.showInstantQueue) {
									$.getJSON(
										"http://api-global.netflix.com/" + abTestInformation.urlPrefix + "/queue",
										{
											success: function(queueMessage) {
												queueList = queueMessage.list;

												configDone = true;
												tryToDisplayOutput();
											},
											error: errorHandler
										});
								}
								else {
									configDone = true;
									tryToDisplayOutput();
								}
							}
						},
						error: errorHandler
					});

				// Retrieve the movie list
				$.getJSON(
					"http://api-global.netflix.com/" + abTestInformation.urlPrefix + "/movieLists",
					{
						success: function(movieListMessage) {
							movieLists = movieListMessage.list;
							tryToDisplayOutput();
						},
						error: errorHandler
					});
			},
			error: errorHandler
		});
}
		
```
略显复杂，为了监控页面加载，同时拉取列表和拉取配置文件，加入了多个条件标志位判断。代码的可读性也不是很强，略显复杂。
#### 响应式编程
响应式编程所要解决的问题和异步编程所要解决的问题是一样的，但是解决问题的思想却是不同的。响应式编程的精华在于响应和事件流，它融合了观察者模式，迭代器模型和函数式编程。
 
在响应式编程中，我们监视事件，然后做出响应（观察者模式）。 这一点其实很相似订阅简讯。 当您订阅Web上发布的新闻，您得提供您的电子邮件地址，每次有新的时事通讯时候，您的电子邮件地址将得到该新闻的一个副本。 同样，我们使用某个函数订阅事件流，每当有一个新的事件时，流将激活这个函数，以使我们的代码能够对事件作出响应。 在这个比喻中，新闻通讯平台是事件流，电子报的每一个新闻是一个事件，电子邮件是您使用订阅事件流的函数。响应式编程就是因为我们得“响应”这些事件而得以命名。

响应式编程中，将这些事件流和数组进行类比，可以通过对数组进行迭代操作，从而到达控制事件执行的目的。 和数组不同的是，数组是在空间值的序列，对数组的操作都是同步的，例如map操作，我们知道每一次映射操作的入参；事件流是随时间的值的序列，例如鼠标移动事件产生的一系列事件对象构成的一个序列，这个序列产生的时间点是未知的，但是却可以抽象成数组，构成事件流。

在响应式编程中，所有函数操作都可以针对一个数组阵列上 - 比如filter，reduce，mapping，reduce，zip - 也可以在事件流完成！ 我们可以过滤的事件流，reduce合并事件流的值，将事件流映射到另一个另外一个，结合组合事件流，将一个流的输入输出到另一个。

### Rx JS

响应式编程是一种编程模型，模型的具体实现语言有很多种，目前有java,.net 等等，这儿只是介绍javascript的响应式编程实现，（目前微软的响应式编程js库 [Rxjs](https://github.com/Reactive-Extensions/RxJS)），前面提到了，在响应式编程中，事件流和数组进行类比，所以下面首先会提一下数组的操作，然后介绍如何用响应式编程处理dom事件和ajax异步请求。
#### 数组的操作
此处介绍的数组操作，和javascript中的操作都尽可能的避免使用索引去实现。

* foreach
* map
* filter
* concatMap
* reduce
* zip
#### DOM事件的响应式处理
#### ajax异步请求的响应式处理




* We can traverse Observables using forEach().
* We can use fromEvent() to convert Events into Observables that never complete.
* We can apply take() and takeUntil() to an Observable to create a new sequence which does complete.


**So how do we convert a callback API into an Observable sequence?** Unfortunately, because callback-based APIs vary so much in their interfaces, we can't create a conversion function like we did with fromEvent(). However there is a more flexible function we can use to build Observable sequences...

** Observable.create() is powerful enough to convert any asynchronous API into an Observable.**  Observable.create() relies on the fact that all asynchronous APIs have the following semantics:

* The client needs to be able to receive data.
* The client needs to be able to receive error information.
* The client needs to be able to be alerted that the operation is complete.
* The client needs to be able to indicate that they're no longer interested in the 
result of the operation.

```
响应式编程：
```
响应式编程(Reactive Programming 或称反应式编程)是一种流行的编程方法，编写代码是基于对变化的反应。它的灵感来自于我们的日常生活，也即我们如何采取行动以及与他人沟通。

我们在执行日常生活活动时，我们会尽可能多任务，但大脑无法处理多任务，不管我们如何努力去做。我们人类实现多任务的唯一办法是在时间线上在任务之间切换。事实上，我们总是切换任务，即使我们没有意识到它。

例如，要执行一个任务：在星巴克喝一杯咖啡饮料，你需要发出一个命令，等待它准备好，然后接受你的饮料。当你在等待的时候，你很可能会找到别的事情做。这是最简单的执行任务的反应(响应)形式，你会在你等待来自咖啡师的“响应”时做别的事情，当你的咖啡已经准备好后，会叫你的名字时。

响应编程能够简化编程，它依赖于事件，代码运行的顺序不是代码行的顺序，而是和一个以上的事件有关，这些事件发生是以随着时间的推移的序列。我们把这一系列事件称为“流”。

何为事件？例如，你知道某个名人总是在发送有趣微博，每次他推发一条微博我们可以称之为一个“事件”。如果你看看这位名人微博系列，你会发现其实是一个随着时间的推移（一系列的事件）发生的一序列的“事件”。

响应式编程就是因为我们得“响应”这些事件而得以命名。例如，想象一下，你在等待某人发送一个很酷商品的促销码，当这条促销码发出时，你会立即响应，去购买这个很酷的商品。这正是什么响应性编程的原理。

为了能够对事件作出反应，我们必须要监督它。 如果我们没有监听的情况下，我们永远不会知道什么时候它会有事件反应。 在微博上，可以设置监测微博的事件，我们遵循简并设置我们的电话，每次她发微博事件时就会第一时间通知我们。 

在响应式编程中，监视事件被称为侦听或订阅该事件。 这一点其实很相似订阅简讯。 当您订阅Web上发布的新闻，您得提供您的电子邮件地址，每次有新的时事通讯时候，您的电子邮件地址将得到该新闻的一个副本。 同样，我们使用某个函数订阅事件流，每当有一个新的事件时，流将激活这个函数，以使我们的代码能够对事件作出响应。 在这个比喻中，新闻通讯平台是事件流，电子报的每一个新闻是一个事件，你的电子邮件是您使用订阅事件流的函数。

现在想象一个动态的通讯，您可以选择主题，并只会发送匹配主题的新闻项目。 你可根据自己的喜好过滤的通讯新闻，而这一点我们可以在事件流做的一样好。 想像你已经使用不同的电子邮件地址订阅多个通讯，以及后来决定你想要的通讯的所有新闻发送到一个新的单电子邮件地址。 简单可以做的是设置通讯新闻发送到新的电子邮件地址的转发邮件规则。 我们可以用事件流同样做到。

** 将事件流可以和通常数组比较。 他们其实很相似。 数组是在空间值的序列，而事件流是随时间的值的序列。 **在响应式编程中，所有函数操作都可以针对一个数组阵列上 - 比如过滤，reduce，mapping，结合，管道 - 也可以在事件流完成！ 我们可以过滤的事件流，reduce合并事件流的值，将事件流映射到另一个另外一个，结合组合事件流，将一个流的输入输出到另一个。